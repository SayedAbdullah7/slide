<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class OtpCodeController extends Controller
{
    //
}
