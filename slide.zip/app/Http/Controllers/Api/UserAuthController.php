<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\PhoneSessionResource;
use App\Http\Traits\Helpers\ApiResponseTrait;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;
use App\Services\{OtpService, UserAuthService, SurveyService};
use App\Models\{User, PhoneSession};
class UserAuthController extends Controller
{
    use ApiResponseTrait;
    protected $otpService, $UserAuthService, $surveyService;

    public function __construct(OtpService $otpService, UserAuthService $UserAuthService, SurveyService $surveyService)
    {
        $this->otpService = $otpService;
        $this->UserAuthService = $UserAuthService;
        $this->surveyService = $surveyService;
    }

    // إرسال OTP
    public function sendOtp(Request $request)
    {
        $request->validate(['phone' => 'required|string']);
        $otp = $this->otpService->generate($request->phone);

        // TODO: إرسال كـ SMS
//        return response()->json(['message'=>'OTP sent','debug_code'=>$otp->code]);
        return $this->respondSuccess('OTP sent');
    }

    // التحقق من OTP → إصدار Session Token
    public function verifyOtp(Request $request)
    {
        $data = $request->validate([
            'phone' => 'required|string',
            'code'  => 'required|string',
        ]);

        $session = $this->otpService->verify($data['phone'], $data['code']);

        if (!$session) {
            return $this->respondError('OTP invalid or expired', 422);
        }

        $user = User::where('phone', $data['phone'])->first();

        if ($user) {
            $token = $this->UserAuthService->login($user);

            return $this->respondSuccessWithData('OTP verified successfully', [
                'is_new_user' => false,
                'token'       => $token,
                'user'        => $user,
                'phone_session' => new PhoneSessionResource($session),
                'has_password' => $user->hasPassword(),
            ]);
        }

        return $this->respondSuccessWithData('OTP verified successfully', [
            'is_new_user'   => true,
            'phone_session' => new PhoneSessionResource($session),
        ]);
    }


    // التسجيل + إجابة الأسئلة

    /**
     * @throws ValidationException
     */
    public function register(Request $request)
    {
        $data = $request->validate([
            'session_token' => 'required|string|exists:phone_sessions,token',
            'full_name'      => 'required|string',
            'email'             => 'nullable|email',
            'national_id'     => 'required|string',
            'birth_date'      => 'required|date',
            'answers'          => 'required|array',

        ]);

        $session = PhoneSession::where('token', $data['session_token'])->first();
        if (!$session || $session->isExpired()) {
//            return response()->json(['message'=>'Session expired'], 422);
            return $this->respondError('Session expired', 422);
        }

        // تحقق من الإجابات
        $this->surveyService->validateAnswers($data['answers']);

        // تسجيل المستخدم
        $user = User::where('phone', $session->phone)->first();
        if (!$user) {
            $user = $this->UserAuthService->register([
                'phone'             => $session->phone,
                'full_name'        => $data['full_name'],
                'email'               => $data['email'] ?? null,
                'national_id'      => $data['national_id'] ?? null,
                'birth_date'       => $data['birth_date'] ?? null,
            ]);
        }

        // حفظ الإجابات
        $this->surveyService->saveAnswers($user, $data['answers']);

        $token = $this->UserAuthService->login($user);

//        return response()->json([
//            'message'=>'Registered successfully',
//            'token' F => $token,
//            'user'   => $user,
//        ]);

        return $this->respondSuccessWithData('Registered successfully', [
            'token'  => $token,
            'user'   => $user,
        ]);
    }


    public function setPassword(Request $request): \Illuminate\Http\JsonResponse
    {
        $data = $request->validate([
            'session_token' => 'required|string|exists:phone_sessions,token',
            'password'      => 'required|string|min:4|max:10|confirmed', // password_confirmation required
        ]);

        $session = PhoneSession::where('token', $data['session_token'])->first();

        if (!$session || $session->isExpired()) {
            return $this->respondError('Session expired', 422);
        }

        $user = User::where('phone', $session->phone)->first();

        if (!$user) {
            return $this->respondError('User not found', 404);
        }

        $user->password = bcrypt($data['password']);
        $user->save();

        return $this->respondSuccess('Password has been set successfully');
    }
}
