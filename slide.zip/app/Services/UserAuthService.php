<?php

namespace App\Services;

use App\Models\User;
use Illuminate\Support\Facades\Hash;
class UserAuthService
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }

    public function register(array $data): User
    {
        return User::create([
            'full_name'    => $data['full_name'],
            'phone'        => $data['phone'],
            'email'        => $data['email'] ?? null,
            'national_id'  => $data['national_id'] ?? null, // ✅ corrected here
            'birth_date'   => $data['birth_date'] ?? null,
            'password'     => Hash::make('default'), // No password input from user
        ]);
    }

    public function login(User $user): string
    {
        return $user->createToken('auth_token')->plainTextToken;
    }
}
